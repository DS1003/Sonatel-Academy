const dataStructure = {
    promotion: {
        id: "",
        libelle: "",
        date_debut: "",
        date_fin: "",
        
    },
};